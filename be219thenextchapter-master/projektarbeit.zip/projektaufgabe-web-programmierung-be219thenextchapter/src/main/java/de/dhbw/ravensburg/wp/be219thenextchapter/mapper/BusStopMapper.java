package de.dhbw.ravensburg.wp.be219thenextchapter.mapper;

public interface BusStopMapper {
}
