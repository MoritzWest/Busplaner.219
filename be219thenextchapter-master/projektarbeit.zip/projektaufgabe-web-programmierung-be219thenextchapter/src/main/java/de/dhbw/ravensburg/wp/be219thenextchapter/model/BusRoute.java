package de.dhbw.ravensburg.wp.be219thenextchapter.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class BusRoute {
    @Id
    @GeneratedValue
    private long id;
    private int frequency;

    @ManyToMany(cascade = CascadeType.ALL) //Tabellendef:Busroute ist der Eigner der Beziehung mit Bus
    @JoinTable(name = "route_bus",
            joinColumns = {
                    @JoinColumn(name = "busRoute_id", referencedColumnName = "id",
                            updatable = false)}, //Buslinien und Pläne ändern sich nicht
            inverseJoinColumns = {
                    @JoinColumn(name = "bus_id", referencedColumnName = "id", //"bus_id" ist der name der Spalte in der neuerstellten Tabelle
                            updatable = false)})
    private List<Bus> busses;

    @ManyToMany(mappedBy = "stoppingBusRoutes", cascade = CascadeType.PERSIST) //->erstmal egal was man da reinschreibt, mind. persist damit wir die Objekte auch speichern können,geht auch all
    private List<BusStop> involvedStops; //das Attribut involvedcast ist das Gegenstück auf der Movieseite?

    @OneToOne(mappedBy = "busRoutes", cascade = CascadeType.ALL) //haben hier bei movie das mappedBy stehen, d.h. in dem Fall ist der Soundtrack der Eigner, nicht der Movie
    private BusSchedule busSchedule;

    public BusRoute(int frequency) { //Konstruktor
        this.frequency = frequency;
    }
}
