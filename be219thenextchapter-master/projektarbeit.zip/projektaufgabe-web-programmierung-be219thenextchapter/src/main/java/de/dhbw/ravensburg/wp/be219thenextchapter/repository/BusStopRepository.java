package de.dhbw.ravensburg.wp.be219thenextchapter.repository;

import de.dhbw.ravensburg.wp.be219thenextchapter.model.BusStop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BusStopRepository extends JpaRepository<BusStop, Long> {
    BusStop findBusStopById(long Id);

    @Query("SELECT FROM BusStop s WHERE s.Id = :param1 AND s.BusRoute.BusSchedule ") //bei from hinschr. von welchen models

}
