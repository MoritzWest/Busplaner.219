package de.dhbw.ravensburg.wp.be219thenextchapter.controller;

import de.dhbw.ravensburg.wp.be219thenextchapter.service.BusRouteService;
import de.dhbw.ravensburg.wp.be219thenextchapter.service.BusRouteServiceImpl;
import de.dhbw.ravensburg.wp.be219thenextchapter.service.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class BusRouteControllerImpl implements BusRouteController {

    private BusRouteService busRouteService;

    @Autowired
    public BusRouteControllerImpl(BusRouteService busRouteService) {
        this.busRouteService = busRouteService;
    }

    //Methodenaufruf aus der Serviceklasse
    public String getBusRouteName() {
        return busRouteService.getBusRoute();
    }
}
