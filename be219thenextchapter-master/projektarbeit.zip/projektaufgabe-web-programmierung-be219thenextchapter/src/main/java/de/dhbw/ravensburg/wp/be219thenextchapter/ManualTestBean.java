package de.dhbw.ravensburg.wp.be219thenextchapter;

import de.dhbw.ravensburg.wp.be219thenextchapter.controller.BusRouteController;
import de.dhbw.ravensburg.wp.be219thenextchapter.controller.BusRouteControllerImpl;
import de.dhbw.ravensburg.wp.be219thenextchapter.model.BusRoute;
import de.dhbw.ravensburg.wp.be219thenextchapter.model.BusStop;
import de.dhbw.ravensburg.wp.be219thenextchapter.repository.BusRouteRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ManualTestBean {

    private BusRouteRepository busRouteRepository;
    private BusRouteControllerImpl busRouteController;

    ManualTestBean(BusRouteRepository busRouteRepository, BusRouteControllerImpl busRouteController) {
        this.busRouteRepository = busRouteRepository;
        this.busRouteController = busRouteController;
    }
    @EventListener(ApplicationReadyEvent.class)
    public void callController() {
        log.info(this.busRouteController.getBusRouteName());
    }

        //Bushaltestellen anlegen
        BusRoute busRoute_1 = new BusRoute(1);

        BusRoute busRoute_2 = new BusRoute(2);

        BusRoute busRoute_3 = new BusRoute(3);

        BusRoute busRoute_4 = new BusRoute(4);

        BusRoute busRoute_5 = new BusRoute(5);

        BusRoute busRoute_6 = new BusRoute(6);

        BusRoute busRoute_7 = new BusRoute(7);

        BusRoute busRoute_8 = new BusRoute(8);

        BusRoute busRoute_9 = new BusRoute(9);

        BusRoute busRoute_10 = new BusRoute(10);


}
