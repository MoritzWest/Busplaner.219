package de.dhbw.ravensburg.wp.be219thenextchapter.service;

public interface BusStopService {
}
