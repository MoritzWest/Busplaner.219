package de.dhbw.ravensburg.wp.be219thenextchapter.service;

import org.springframework.stereotype.Service;

@Service
public class BusStopServiceImpl implements BusStopService{
}
