package de.dhbw.ravensburg.wp.be219thenextchapter.dto;

public class BusStopDTO {
}
