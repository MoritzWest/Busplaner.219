package de.dhbw.ravensburg.wp.be219thenextchapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataApplication {
    public static void main(String[] args) {
        SpringApplication.run(de.dhbw.ravensburg.wp.be219thenextchapter.SpringDataApplication.class, args);
    }

}
