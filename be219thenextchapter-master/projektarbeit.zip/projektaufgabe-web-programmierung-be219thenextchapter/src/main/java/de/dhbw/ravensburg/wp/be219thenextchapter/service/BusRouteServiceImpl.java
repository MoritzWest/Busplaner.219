package de.dhbw.ravensburg.wp.be219thenextchapter.service;

import org.springframework.stereotype.Service;

@Service
public class BusRouteServiceImpl implements BusRouteService{
    //Methode zur Ausgabe von dem Bushaltestellenname. Wird von BusRouteControllerImpl verwendet.
    public String getBusRoute() { return "BusRouteServiceImpl"; }
}
