package de.dhbw.ravensburg.wp.be219thenextchapter.controller;

public interface BusStopController {
}
