package de.dhbw.ravensburg.wp.be219thenextchapter.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BusScheduleControllerImpl {
}
