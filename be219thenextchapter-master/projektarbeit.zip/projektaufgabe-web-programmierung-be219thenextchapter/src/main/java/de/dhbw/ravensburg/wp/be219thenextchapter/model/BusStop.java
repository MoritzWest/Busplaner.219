package de.dhbw.ravensburg.wp.be219thenextchapter.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class BusStop {
    @Id
    @GeneratedValue
    private long id;
    private String name;

    @ManyToMany(cascade = CascadeType.ALL) //Tabellendef:Bushaltestelle ist der Eigner der Beziehung mit BusRoute
    @JoinTable(name = "stop_route",
            joinColumns = {
                    @JoinColumn(name = "busStop_id", referencedColumnName = "id",
                            updatable = false)}, //Buslinien und Pläne ändern sich nicht
            inverseJoinColumns = {
                    @JoinColumn(name = "busRoute_id", referencedColumnName = "id", //"bus_Route" ist der name der Spalte in der neuerstellten Tabelle
                            updatable = false)})
    private List<BusRoute> stoppingBusRoutes;

    public BusStop (String name){
        this.name = name;
 }

}
