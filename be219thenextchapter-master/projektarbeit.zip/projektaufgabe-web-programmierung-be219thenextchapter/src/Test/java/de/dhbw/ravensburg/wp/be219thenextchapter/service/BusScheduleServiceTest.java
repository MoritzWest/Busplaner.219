package de.dhbw.ravensburg.wp.be219thenextchapter.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BusScheduleServiceTest {
}
