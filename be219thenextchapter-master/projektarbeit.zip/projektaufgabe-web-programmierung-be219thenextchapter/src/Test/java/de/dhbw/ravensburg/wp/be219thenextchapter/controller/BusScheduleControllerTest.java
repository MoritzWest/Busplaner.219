package de.dhbw.ravensburg.wp.be219thenextchapter.controller;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BusScheduleControllerTest {
}
