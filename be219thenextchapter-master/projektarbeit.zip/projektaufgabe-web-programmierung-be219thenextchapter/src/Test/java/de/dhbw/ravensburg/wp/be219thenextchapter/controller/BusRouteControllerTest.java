package de.dhbw.ravensburg.wp.be219thenextchapter.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BusRouteControllerTest {

    @Autowired
    BusRouteController busRouteController;
}
